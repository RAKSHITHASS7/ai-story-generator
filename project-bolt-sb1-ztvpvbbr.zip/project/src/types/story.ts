export interface Story {
  id: string;
  title: string;
  genre: string;
  theme: string | null;
  characters: string | null;
  keywords: string | null;
  prompt: string;
  content: string;
  word_count: number;
  user_id: string | null;
  created_at: string;
}

export interface StoryFormData {
  genre: string;
  theme: string;
  characters: string;
  keywords: string;
  tone: string;
}

export const GENRES = [
  'Fantasy',
  'Sci-Fi',
  'Horror',
  'Romance',
  'Mystery',
  'Adventure',
  'Drama',
  'Comedy',
  'Thriller',
  'Historical',
];

export const TONES = [
  'Lighthearted',
  'Dark',
  'Mysterious',
  'Inspirational',
  'Humorous',
  'Dramatic',
  'Suspenseful',
  'Romantic',
];
