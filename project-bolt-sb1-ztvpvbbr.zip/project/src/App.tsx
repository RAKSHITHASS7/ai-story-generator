import { useState, useEffect } from 'react';
import { BookText, AlertCircle } from 'lucide-react';
import StoryForm from './components/StoryForm';
import StoryDisplay from './components/StoryDisplay';
import StoryHistory from './components/StoryHistory';
import { Story, StoryFormData } from './types/story';
import { generateStory, getRecentStories, deleteStory } from './services/storyService';

function App() {
  const [currentStory, setCurrentStory] = useState<Story | null>(null);
  const [stories, setStories] = useState<Story[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadStories();
  }, []);

  const loadStories = async () => {
    try {
      setIsLoading(true);
      const recentStories = await getRecentStories(20);
      setStories(recentStories);
      if (recentStories.length > 0 && !currentStory) {
        setCurrentStory(recentStories[0]);
      }
    } catch (err) {
      console.error('Error loading stories:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerate = async (formData: StoryFormData) => {
    setIsGenerating(true);
    setError(null);

    try {
      const newStory = await generateStory(formData);
      setCurrentStory(newStory);
      setStories((prev) => [newStory, ...prev]);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to generate story';
      setError(errorMessage);
      console.error('Error generating story:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSelectStory = (story: Story) => {
    setCurrentStory(story);
    setError(null);
  };

  const handleDeleteStory = async (id: string) => {
    if (!confirm('Are you sure you want to delete this story?')) {
      return;
    }

    try {
      await deleteStory(id);
      setStories((prev) => prev.filter((s) => s.id !== id));
      if (currentStory?.id === id) {
        setCurrentStory(stories.length > 1 ? stories[0] : null);
      }
    } catch (err) {
      console.error('Error deleting story:', err);
      alert('Failed to delete story');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-3 rounded-xl shadow-lg">
              <BookText className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                AI Story Generator
              </h1>
              <p className="text-sm text-gray-600 mt-1">
                Create unique stories with the power of Generative AI
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-red-800">Error</h3>
              <p className="text-sm text-red-700 mt-1">{error}</p>
              {error.includes('API key') && (
                <p className="text-sm text-red-600 mt-2">
                  Please configure your OpenAI API key in the Supabase dashboard under Edge Functions secrets.
                </p>
              )}
            </div>
          </div>
        )}

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <StoryForm onGenerate={handleGenerate} isGenerating={isGenerating} />
            <StoryDisplay story={currentStory} />
          </div>

          <div className="lg:col-span-1">
            {isLoading ? (
              <div className="bg-white rounded-xl shadow-lg p-8 text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                <p className="text-gray-500 mt-4">Loading stories...</p>
              </div>
            ) : (
              <StoryHistory
                stories={stories}
                onSelectStory={handleSelectStory}
                onDeleteStory={handleDeleteStory}
                selectedStoryId={currentStory?.id || null}
              />
            )}
          </div>
        </div>
      </main>

      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center text-sm text-gray-600">
            <p>Powered by Generative AI and Natural Language Processing</p>
            <p className="mt-1 text-xs text-gray-500">
              Using advanced Transformer models for creative story generation
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
