import { supabase } from '../lib/supabase';
import { Story, StoryFormData } from '../types/story';

export async function generateStory(formData: StoryFormData): Promise<Story> {
  const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-story`;

  const headers = {
    Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
    'Content-Type': 'application/json',
  };

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      genre: formData.genre,
      theme: formData.theme || undefined,
      characters: formData.characters || undefined,
      keywords: formData.keywords || undefined,
      tone: formData.tone || undefined,
    }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || error.message || 'Failed to generate story');
  }

  const result = await response.json();

  const { data: savedStory, error: dbError } = await supabase
    .from('stories')
    .insert({
      title: result.title,
      genre: formData.genre,
      theme: formData.theme || null,
      characters: formData.characters || null,
      keywords: formData.keywords || null,
      prompt: result.prompt,
      content: result.content,
      word_count: result.wordCount,
    })
    .select()
    .single();

  if (dbError) {
    throw new Error(`Failed to save story: ${dbError.message}`);
  }

  return savedStory;
}

export async function getRecentStories(limit: number = 10): Promise<Story[]> {
  const { data, error } = await supabase
    .from('stories')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) {
    throw new Error(`Failed to fetch stories: ${error.message}`);
  }

  return data || [];
}

export async function deleteStory(id: string): Promise<void> {
  const { error } = await supabase.from('stories').delete().eq('id', id);

  if (error) {
    throw new Error(`Failed to delete story: ${error.message}`);
  }
}
