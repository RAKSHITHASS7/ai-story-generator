import { BookOpen, Download, Copy, Check } from 'lucide-react';
import { useState } from 'react';
import { Story } from '../types/story';

interface StoryDisplayProps {
  story: Story | null;
}

export default function StoryDisplay({ story }: StoryDisplayProps) {
  const [copied, setCopied] = useState(false);

  if (!story) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-12 text-center">
        <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <p className="text-gray-500 text-lg">Your generated story will appear here</p>
      </div>
    );
  }

  const handleCopy = async () => {
    await navigator.clipboard.writeText(story.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([`${story.title}\n\n${story.content}`], {
      type: 'text/plain',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${story.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h2 className="text-2xl font-bold text-white mb-2">{story.title}</h2>
            <div className="flex flex-wrap gap-3 text-sm text-blue-100">
              <span className="bg-blue-500/30 px-3 py-1 rounded-full">{story.genre}</span>
              <span className="bg-blue-500/30 px-3 py-1 rounded-full">
                {story.word_count} words
              </span>
              <span className="bg-blue-500/30 px-3 py-1 rounded-full">
                {new Date(story.created_at).toLocaleDateString()}
              </span>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleCopy}
              className="bg-white/20 hover:bg-white/30 text-white p-2 rounded-lg transition"
              title="Copy to clipboard"
            >
              {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
            </button>
            <button
              onClick={handleDownload}
              className="bg-white/20 hover:bg-white/30 text-white p-2 rounded-lg transition"
              title="Download story"
            >
              <Download className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="p-8">
        <div className="prose prose-lg max-w-none">
          {story.content.split('\n\n').map((paragraph, index) => (
            <p key={index} className="text-gray-700 leading-relaxed mb-4">
              {paragraph}
            </p>
          ))}
        </div>
      </div>

      {(story.theme || story.characters || story.keywords) && (
        <div className="border-t border-gray-200 bg-gray-50 p-6">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Story Elements</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            {story.theme && (
              <div>
                <span className="font-medium text-gray-600">Theme:</span>
                <p className="text-gray-800 mt-1">{story.theme}</p>
              </div>
            )}
            {story.characters && (
              <div>
                <span className="font-medium text-gray-600">Characters:</span>
                <p className="text-gray-800 mt-1">{story.characters}</p>
              </div>
            )}
            {story.keywords && (
              <div>
                <span className="font-medium text-gray-600">Keywords:</span>
                <p className="text-gray-800 mt-1">{story.keywords}</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
