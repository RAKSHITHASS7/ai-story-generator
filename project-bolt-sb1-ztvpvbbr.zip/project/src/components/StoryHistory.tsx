import { Clock, BookOpen, Trash2 } from 'lucide-react';
import { Story } from '../types/story';

interface StoryHistoryProps {
  stories: Story[];
  onSelectStory: (story: Story) => void;
  onDeleteStory: (id: string) => void;
  selectedStoryId: string | null;
}

export default function StoryHistory({
  stories,
  onSelectStory,
  onDeleteStory,
  selectedStoryId,
}: StoryHistoryProps) {
  if (stories.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-8 text-center">
        <Clock className="w-12 h-12 text-gray-300 mx-auto mb-3" />
        <p className="text-gray-500">No stories generated yet</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 p-4">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-white" />
          <h3 className="text-lg font-semibold text-white">Recent Stories</h3>
        </div>
      </div>
      <div className="divide-y divide-gray-200 max-h-96 overflow-y-auto">
        {stories.map((story) => (
          <div
            key={story.id}
            className={`p-4 hover:bg-gray-50 transition cursor-pointer group ${
              selectedStoryId === story.id ? 'bg-blue-50' : ''
            }`}
            onClick={() => onSelectStory(story)}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <BookOpen className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  <h4 className="font-semibold text-gray-800 truncate">{story.title}</h4>
                </div>
                <div className="flex flex-wrap gap-2 text-xs text-gray-500 mb-2">
                  <span className="bg-gray-100 px-2 py-1 rounded">{story.genre}</span>
                  <span>{story.word_count} words</span>
                  <span>{new Date(story.created_at).toLocaleDateString()}</span>
                </div>
                <p className="text-sm text-gray-600 line-clamp-2">
                  {story.content.substring(0, 100)}...
                </p>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDeleteStory(story.id);
                }}
                className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition flex-shrink-0"
                title="Delete story"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
