import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface StoryRequest {
  genre: string;
  theme?: string;
  characters?: string;
  keywords?: string;
  tone?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { genre, theme, characters, keywords, tone }: StoryRequest = await req.json();

    const openaiApiKey = Deno.env.get("OPENAI_API_KEY");
    
    if (!openaiApiKey) {
      return new Response(
        JSON.stringify({ 
          error: "OpenAI API key not configured",
          message: "Please configure your OPENAI_API_KEY environment variable in the Supabase dashboard."
        }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const prompt = buildPrompt({ genre, theme, characters, keywords, tone });

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openaiApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are a creative storyteller. Generate engaging, well-structured stories based on the given prompts. Make stories vivid, immersive, and complete with a clear beginning, middle, and end."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.8,
        max_tokens: 1500,
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`OpenAI API error: ${error}`);
    }

    const data = await response.json();
    const storyContent = data.choices[0].message.content;
    const wordCount = storyContent.split(/\s+/).length;

    const title = generateTitle(genre, theme, characters);

    return new Response(
      JSON.stringify({
        title,
        content: storyContent,
        prompt,
        wordCount,
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ 
        error: error.message || "Failed to generate story"
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});

function buildPrompt(params: StoryRequest): string {
  const { genre, theme, characters, keywords, tone } = params;
  
  let prompt = `Write a ${tone || 'engaging'} ${genre} story`;
  
  if (theme) {
    prompt += ` about ${theme}`;
  }
  
  if (characters) {
    prompt += ` featuring ${characters}`;
  }
  
  if (keywords) {
    prompt += `. Include these elements: ${keywords}`;
  }
  
  prompt += ". Make it creative, descriptive, and complete with a satisfying ending. Aim for around 400-600 words.";
  
  return prompt;
}

function generateTitle(genre: string, theme?: string, characters?: string): string {
  if (theme) {
    const themeWords = theme.split(' ');
    const mainWord = themeWords.find(w => w.length > 4) || themeWords[0];
    return `The ${mainWord.charAt(0).toUpperCase() + mainWord.slice(1)} ${genre === 'Fantasy' ? 'Quest' : genre === 'Sci-Fi' ? 'Odyssey' : genre === 'Horror' ? 'Night' : 'Story'}`;
  }
  
  if (characters) {
    const charName = characters.split(',')[0].trim().split(' ')[0];
    return `${charName}'s ${genre} Adventure`;
  }
  
  const genericTitles: Record<string, string[]> = {
    'Fantasy': ['The Enchanted Quest', 'Realm of Wonders', 'The Mystic Journey'],
    'Sci-Fi': ['Beyond the Stars', 'The Future Awaits', 'Cosmic Odyssey'],
    'Horror': ['Shadows of Fear', 'The Dark Hour', 'Whispers in the Night'],
    'Romance': ['Hearts Entwined', 'Love\'s Journey', 'A Timeless Bond'],
    'Mystery': ['The Hidden Truth', 'Secrets Unveiled', 'The Last Clue'],
    'Adventure': ['The Great Expedition', 'Uncharted Territory', 'Journey Unknown'],
  };
  
  const titles = genericTitles[genre] || ['An Untold Story', 'The Tale Begins', 'A New Chapter'];
  return titles[Math.floor(Math.random() * titles.length)];
}