/*
  # Story Generation System Database Schema

  ## Overview
  This migration creates the database structure for an AI-powered story generation system.

  ## New Tables
  
  ### `stories`
  Stores all generated stories with their metadata:
  - `id` (uuid, primary key) - Unique identifier for each story
  - `title` (text) - Auto-generated or user-provided title
  - `genre` (text) - Story genre (Fantasy, Sci-Fi, Horror, Romance, etc.)
  - `theme` (text) - Main theme or concept
  - `characters` (text) - Character names or descriptions
  - `keywords` (text) - Keywords used in generation
  - `prompt` (text) - The engineered prompt sent to AI
  - `content` (text) - The generated story content
  - `word_count` (integer) - Number of words in the story
  - `created_at` (timestamptz) - When the story was generated
  - `user_id` (uuid) - Reference to auth.users (nullable for anonymous users)

  ## Security
  - Enable Row Level Security on all tables
  - Allow public read access for demo purposes
  - Allow authenticated users to manage their own stories
  - Allow anonymous story creation for demo experience
*/

-- Create stories table
CREATE TABLE IF NOT EXISTS stories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT 'Untitled Story',
  genre text NOT NULL,
  theme text,
  characters text,
  keywords text,
  prompt text NOT NULL,
  content text NOT NULL,
  word_count integer DEFAULT 0,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE stories ENABLE ROW LEVEL SECURITY;

-- Allow anyone to read stories (for demo/showcase purposes)
CREATE POLICY "Anyone can read stories"
  ON stories
  FOR SELECT
  TO public
  USING (true);

-- Allow anyone to create stories (for demo purposes)
CREATE POLICY "Anyone can create stories"
  ON stories
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Authenticated users can update their own stories
CREATE POLICY "Users can update own stories"
  ON stories
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Authenticated users can delete their own stories
CREATE POLICY "Users can delete own stories"
  ON stories
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS stories_created_at_idx ON stories(created_at DESC);
CREATE INDEX IF NOT EXISTS stories_user_id_idx ON stories(user_id);
CREATE INDEX IF NOT EXISTS stories_genre_idx ON stories(genre);