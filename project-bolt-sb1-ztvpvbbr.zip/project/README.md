# AI Story Generator

A production-ready web application that generates creative stories using Generative AI and Natural Language Processing.

## Features

- **AI-Powered Story Generation**: Creates unique stories using advanced Transformer models (GPT-3.5-turbo)
- **Customizable Input**: Select genre, theme, characters, keywords, and tone
- **Prompt Engineering**: Intelligently constructs prompts to guide AI story creation
- **Story Management**: Save, view, and manage generated stories
- **Story History**: Browse previously generated stories
- **Export Functionality**: Copy to clipboard or download stories as text files
- **Beautiful UI**: Modern, responsive design with smooth animations
- **Real-time Feedback**: Loading states and error handling

## Technologies Used

- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Backend**: Supabase (Database + Edge Functions)
- **AI Model**: OpenAI GPT-3.5-turbo
- **Database**: PostgreSQL (via Supabase)

## System Architecture

### Modules

1. **User Input Module** - Form to collect story parameters
2. **Prompt Engineering Module** - Constructs optimized AI prompts
3. **Generative AI Module** - Calls OpenAI API via Edge Function
4. **Story Storage Module** - Saves stories to Supabase database
5. **Story Display Module** - Renders generated stories
6. **History Module** - Manages story collection

## Setup Instructions

### Prerequisites

- Node.js 18+ installed
- Supabase account
- OpenAI API key

### Configuration

1. **Supabase Configuration** (Already configured)
   - Database tables are already set up
   - Edge Function is deployed

2. **OpenAI API Key** (Required)

   To enable story generation, configure your OpenAI API key:

   a. Get your API key from [OpenAI Platform](https://platform.openai.com/api-keys)

   b. Add it to Supabase:
      - Go to your [Supabase Dashboard](https://supabase.com/dashboard)
      - Select your project
      - Navigate to **Edge Functions** → **Secrets**
      - Add a new secret:
        - Name: `OPENAI_API_KEY`
        - Value: Your OpenAI API key

### Installation

```bash
npm install
```

### Running the Application

```bash
npm run dev
```

The application will start at `http://localhost:5173`

### Building for Production

```bash
npm run build
```

## Usage

1. **Select Genre**: Choose from Fantasy, Sci-Fi, Horror, Romance, Mystery, etc.
2. **Set Tone**: Pick the storytelling tone (Lighthearted, Dark, Mysterious, etc.)
3. **Add Details** (Optional):
   - Theme or concept
   - Character names/descriptions
   - Keywords or story elements
4. **Generate**: Click "Generate Story" and wait for AI to create your story
5. **Enjoy**: Read, copy, or download your generated story
6. **Browse History**: Access previously generated stories from the sidebar

## Database Schema

### `stories` Table

| Column      | Type      | Description                          |
|-------------|-----------|--------------------------------------|
| id          | uuid      | Primary key                          |
| title       | text      | Story title                          |
| genre       | text      | Story genre                          |
| theme       | text      | Story theme/concept                  |
| characters  | text      | Character descriptions               |
| keywords    | text      | Story keywords                       |
| prompt      | text      | AI prompt used                       |
| content     | text      | Generated story content              |
| word_count  | integer   | Number of words                      |
| user_id     | uuid      | User reference (nullable)            |
| created_at  | timestamp | Creation timestamp                   |

## Security Features

- Row Level Security (RLS) enabled
- Public read access for demo purposes
- Authenticated user restrictions for updates/deletes
- API keys secured in Edge Functions
- CORS headers properly configured

## API Endpoints

### Edge Function: `generate-story`

**Endpoint**: `{SUPABASE_URL}/functions/v1/generate-story`

**Method**: POST

**Request Body**:
```json
{
  "genre": "Fantasy",
  "theme": "A journey to discover truth",
  "characters": "A brave knight, a wise wizard",
  "keywords": "magic, dragons, prophecy",
  "tone": "Epic"
}
```

**Response**:
```json
{
  "title": "The Mystic Journey",
  "content": "Story content...",
  "prompt": "Generated prompt...",
  "wordCount": 542
}
```

## Available Genres

- Fantasy
- Sci-Fi
- Horror
- Romance
- Mystery
- Adventure
- Drama
- Comedy
- Thriller
- Historical

## Available Tones

- Lighthearted
- Dark
- Mysterious
- Inspirational
- Humorous
- Dramatic
- Suspenseful
- Romantic

## Error Handling

The application includes comprehensive error handling:
- API key validation
- Network error recovery
- User-friendly error messages
- Graceful degradation

## Future Enhancements

- User authentication for personalized story collections
- Story editing and refinement
- Multiple AI model support
- Story rating and favorites
- Social sharing features
- Advanced prompt templates
- Story continuation/expansion

## License

This project is created for educational and demonstration purposes.

## Support

For issues or questions, please refer to the documentation or contact support.
