import { BookOpen, Sparkles } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <BookOpen className="h-10 w-10 text-blue-400" />
              <Sparkles className="h-5 w-5 text-yellow-400 absolute -top-1 -right-1 animate-pulse" />
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight">AI Story Generator</h1>
              <p className="text-slate-300 text-sm mt-1">Powered by Natural Language Processing</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
