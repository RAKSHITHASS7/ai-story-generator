import { Download, Copy, Check, BookMarked } from 'lucide-react';
import { useState } from 'react';
import type { Story } from '../lib/supabase';

interface StoryDisplayProps {
  story: Story;
  onSave?: (id: string) => void;
}

export function StoryDisplay({ story, onSave }: StoryDisplayProps) {
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(`${story.title}\n\n${story.content}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([`${story.title}\n\n${story.content}`], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${story.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSave = () => {
    if (onSave) {
      onSave(story.id);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
      <div className="bg-gradient-to-r from-slate-50 to-blue-50 px-8 py-6 border-b border-slate-200">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h2 className="text-3xl font-bold text-slate-900 mb-2">{story.title}</h2>
            <div className="flex flex-wrap gap-2 mt-3">
              <span className="px-3 py-1 bg-blue-100 text-blue-800 text-xs font-semibold rounded-full">
                {story.genre}
              </span>
              {story.theme && (
                <span className="px-3 py-1 bg-green-100 text-green-800 text-xs font-semibold rounded-full">
                  {story.theme}
                </span>
              )}
              <span className="px-3 py-1 bg-slate-200 text-slate-700 text-xs font-semibold rounded-full">
                {story.word_count} words
              </span>
            </div>
          </div>
          <div className="flex gap-2 ml-4">
            <button
              onClick={handleCopy}
              className="p-2 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
              title="Copy to clipboard"
            >
              {copied ? (
                <Check className="h-5 w-5 text-green-600" />
              ) : (
                <Copy className="h-5 w-5 text-slate-600" />
              )}
            </button>
            <button
              onClick={handleDownload}
              className="p-2 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
              title="Download as text file"
            >
              <Download className="h-5 w-5 text-slate-600" />
            </button>
            {onSave && (
              <button
                onClick={handleSave}
                className="p-2 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
                title="Save to collection"
              >
                <BookMarked className={`h-5 w-5 ${saved ? 'text-yellow-600' : 'text-slate-600'}`} />
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="p-8">
        <div className="prose prose-slate max-w-none">
          {story.content.split('\n\n').map((paragraph, index) => (
            <p key={index} className="text-slate-700 leading-relaxed mb-4 text-lg">
              {paragraph}
            </p>
          ))}
        </div>

        {(story.characters.length > 0 || story.keywords.length > 0) && (
          <div className="mt-8 pt-6 border-t border-slate-200">
            {story.characters.length > 0 && (
              <div className="mb-4">
                <h3 className="text-sm font-semibold text-slate-700 mb-2">Characters:</h3>
                <div className="flex flex-wrap gap-2">
                  {story.characters.map((char, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-blue-50 text-blue-700 text-sm rounded-full"
                    >
                      {char}
                    </span>
                  ))}
                </div>
              </div>
            )}
            {story.keywords.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold text-slate-700 mb-2">Keywords:</h3>
                <div className="flex flex-wrap gap-2">
                  {story.keywords.map((keyword, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-green-50 text-green-700 text-sm rounded-full"
                    >
                      {keyword}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
