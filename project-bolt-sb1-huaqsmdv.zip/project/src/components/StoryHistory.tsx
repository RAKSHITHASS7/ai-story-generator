import { Clock, BookOpen, Eye } from 'lucide-react';
import type { Story } from '../lib/supabase';

interface StoryHistoryProps {
  stories: Story[];
  onViewStory: (story: Story) => void;
  isLoading?: boolean;
}

export function StoryHistory({ stories, onViewStory, isLoading }: StoryHistoryProps) {
  if (isLoading) {
    return (
      <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-200">
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent" />
        </div>
      </div>
    );
  }

  if (stories.length === 0) {
    return (
      <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-200">
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <BookOpen className="h-16 w-16 text-slate-300 mb-4" />
          <h3 className="text-xl font-semibold text-slate-900 mb-2">No Stories Yet</h3>
          <p className="text-slate-600">Generate your first story to see it appear here!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-200">
      <div className="flex items-center space-x-3 mb-6">
        <Clock className="h-6 w-6 text-blue-600" />
        <h2 className="text-2xl font-bold text-slate-900">Story History</h2>
      </div>

      <div className="space-y-4">
        {stories.map((story) => (
          <div
            key={story.id}
            className="border border-slate-200 rounded-xl p-5 hover:border-blue-300 hover:shadow-md transition-all cursor-pointer group"
            onClick={() => onViewStory(story)}
          >
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-semibold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors truncate">
                  {story.title}
                </h3>
                <p className="text-slate-600 text-sm line-clamp-2 mb-3">
                  {story.content}
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-semibold rounded">
                    {story.genre}
                  </span>
                  <span className="px-2 py-1 bg-slate-200 text-slate-700 text-xs font-semibold rounded">
                    {story.word_count} words
                  </span>
                  <span className="px-2 py-1 bg-slate-200 text-slate-700 text-xs rounded">
                    {new Date(story.created_at).toLocaleDateString()}
                  </span>
                </div>
              </div>
              <button
                className="ml-4 p-2 bg-blue-50 text-blue-600 rounded-lg group-hover:bg-blue-100 transition-colors"
                title="View story"
              >
                <Eye className="h-5 w-5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
