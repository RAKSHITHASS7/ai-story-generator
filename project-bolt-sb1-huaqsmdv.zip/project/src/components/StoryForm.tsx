import { useState } from 'react';
import { Wand2, Plus, X } from 'lucide-react';

interface StoryFormProps {
  onGenerate: (params: StoryParams) => void;
  isGenerating: boolean;
}

export interface StoryParams {
  genre: string;
  theme: string;
  characters: string[];
  keywords: string[];
  length: 'short' | 'medium' | 'long';
}

const GENRES = [
  { value: 'fantasy', label: 'Fantasy', description: 'Magic, mythical creatures, and epic quests' },
  { value: 'scifi', label: 'Science Fiction', description: 'Technology, space, and the future' },
  { value: 'mystery', label: 'Mystery', description: 'Puzzles, clues, and investigations' },
  { value: 'romance', label: 'Romance', description: 'Love, relationships, and emotions' },
  { value: 'horror', label: 'Horror', description: 'Fear, suspense, and the supernatural' },
  { value: 'adventure', label: 'Adventure', description: 'Exploration, danger, and discovery' },
  { value: 'thriller', label: 'Thriller', description: 'Tension, danger, and high stakes' },
];

export function StoryForm({ onGenerate, isGenerating }: StoryFormProps) {
  const [genre, setGenre] = useState('fantasy');
  const [theme, setTheme] = useState('');
  const [characters, setCharacters] = useState<string[]>([]);
  const [keywords, setKeywords] = useState<string[]>([]);
  const [length, setLength] = useState<'short' | 'medium' | 'long'>('medium');
  const [characterInput, setCharacterInput] = useState('');
  const [keywordInput, setKeywordInput] = useState('');

  const handleAddCharacter = () => {
    if (characterInput.trim() && characters.length < 5) {
      setCharacters([...characters, characterInput.trim()]);
      setCharacterInput('');
    }
  };

  const handleRemoveCharacter = (index: number) => {
    setCharacters(characters.filter((_, i) => i !== index));
  };

  const handleAddKeyword = () => {
    if (keywordInput.trim() && keywords.length < 10) {
      setKeywords([...keywords, keywordInput.trim()]);
      setKeywordInput('');
    }
  };

  const handleRemoveKeyword = (index: number) => {
    setKeywords(keywords.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate({ genre, theme, characters, keywords, length });
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-200">
      <div className="flex items-center space-x-3 mb-6">
        <Wand2 className="h-6 w-6 text-blue-600" />
        <h2 className="text-2xl font-bold text-slate-900">Create Your Story</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-3">
            Genre *
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {GENRES.map((g) => (
              <button
                key={g.value}
                type="button"
                onClick={() => setGenre(g.value)}
                className={`p-4 rounded-xl border-2 transition-all text-left ${
                  genre === g.value
                    ? 'border-blue-600 bg-blue-50 shadow-md'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="font-semibold text-slate-900">{g.label}</div>
                <div className="text-xs text-slate-600 mt-1">{g.description}</div>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label htmlFor="theme" className="block text-sm font-semibold text-slate-700 mb-2">
            Theme / Central Idea
          </label>
          <input
            id="theme"
            type="text"
            value={theme}
            onChange={(e) => setTheme(e.target.value)}
            placeholder="e.g., overcoming adversity, finding courage, betrayal and redemption"
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
          />
          <p className="text-xs text-slate-500 mt-1">Optional - Leave blank for automatic theme selection</p>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Characters (optional)
          </label>
          <div className="flex gap-2 mb-3">
            <input
              type="text"
              value={characterInput}
              onChange={(e) => setCharacterInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddCharacter())}
              placeholder="Enter character name"
              className="flex-1 px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
              disabled={characters.length >= 5}
            />
            <button
              type="button"
              onClick={handleAddCharacter}
              disabled={!characterInput.trim() || characters.length >= 5}
              className="px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              Add
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {characters.map((char, index) => (
              <span
                key={index}
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-blue-100 text-blue-800 rounded-full text-sm font-medium"
              >
                {char}
                <button
                  type="button"
                  onClick={() => handleRemoveCharacter(index)}
                  className="hover:bg-blue-200 rounded-full p-0.5 transition"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
          </div>
          <p className="text-xs text-slate-500 mt-2">Add up to 5 character names</p>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Keywords (optional)
          </label>
          <div className="flex gap-2 mb-3">
            <input
              type="text"
              value={keywordInput}
              onChange={(e) => setKeywordInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddKeyword())}
              placeholder="Enter keyword or concept"
              className="flex-1 px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
              disabled={keywords.length >= 10}
            />
            <button
              type="button"
              onClick={handleAddKeyword}
              disabled={!keywordInput.trim() || keywords.length >= 10}
              className="px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              Add
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {keywords.map((keyword, index) => (
              <span
                key={index}
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-green-100 text-green-800 rounded-full text-sm font-medium"
              >
                {keyword}
                <button
                  type="button"
                  onClick={() => handleRemoveKeyword(index)}
                  className="hover:bg-green-200 rounded-full p-0.5 transition"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
          </div>
          <p className="text-xs text-slate-500 mt-2">Add up to 10 keywords to weave into your story</p>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-3">
            Story Length
          </label>
          <div className="grid grid-cols-3 gap-3">
            {[
              { value: 'short', label: 'Short', desc: '~200 words' },
              { value: 'medium', label: 'Medium', desc: '~400 words' },
              { value: 'long', label: 'Long', desc: '~700 words' },
            ].map((l) => (
              <button
                key={l.value}
                type="button"
                onClick={() => setLength(l.value as 'short' | 'medium' | 'long')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  length === l.value
                    ? 'border-blue-600 bg-blue-50 shadow-md'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="font-semibold text-slate-900">{l.label}</div>
                <div className="text-xs text-slate-600 mt-1">{l.desc}</div>
              </button>
            ))}
          </div>
        </div>

        <button
          type="submit"
          disabled={isGenerating}
          className="w-full py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-blue-800 disabled:from-slate-400 disabled:to-slate-500 disabled:cursor-not-allowed transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
        >
          {isGenerating ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
              Generating Your Story...
            </>
          ) : (
            <>
              <Wand2 className="h-5 w-5" />
              Generate Story
            </>
          )}
        </button>
      </form>
    </div>
  );
}
