import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { StoryForm, StoryParams } from './components/StoryForm';
import { StoryDisplay } from './components/StoryDisplay';
import { StoryHistory } from './components/StoryHistory';
import { supabase, Story } from './lib/supabase';
import { AlertCircle } from 'lucide-react';

function App() {
  const [currentStory, setCurrentStory] = useState<Story | null>(null);
  const [storyHistory, setStoryHistory] = useState<Story[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [view, setView] = useState<'form' | 'story'>('form');

  useEffect(() => {
    loadStoryHistory();
  }, []);

  const loadStoryHistory = async () => {
    try {
      setIsLoadingHistory(true);
      const { data, error } = await supabase
        .from('stories')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      setStoryHistory(data || []);
    } catch (err) {
      console.error('Error loading history:', err);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  const generateStory = async (params: StoryParams) => {
    try {
      setIsGenerating(true);
      setError(null);

      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-story`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(params),
      });

      if (!response.ok) {
        throw new Error('Failed to generate story');
      }

      const generatedStory = await response.json();

      const { data, error } = await supabase
        .from('stories')
        .insert([
          {
            title: generatedStory.title,
            content: generatedStory.content,
            genre: params.genre,
            theme: params.theme || null,
            characters: params.characters,
            keywords: params.keywords,
            word_count: generatedStory.wordCount,
          },
        ])
        .select()
        .single();

      if (error) throw error;

      setCurrentStory(data);
      setView('story');
      loadStoryHistory();
    } catch (err) {
      console.error('Error generating story:', err);
      setError(err instanceof Error ? err.message : 'Failed to generate story. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleViewStory = (story: Story) => {
    setCurrentStory(story);
    setView('story');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNewStory = () => {
    setCurrentStory(null);
    setView('form');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-50">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-red-900">Error</h3>
              <p className="text-red-700 text-sm mt-1">{error}</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {view === 'form' ? (
              <StoryForm onGenerate={generateStory} isGenerating={isGenerating} />
            ) : currentStory ? (
              <>
                <StoryDisplay story={currentStory} />
                <button
                  onClick={handleNewStory}
                  className="mt-6 w-full py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all shadow-lg hover:shadow-xl"
                >
                  Generate Another Story
                </button>
              </>
            ) : null}
          </div>

          <div className="lg:col-span-1">
            <StoryHistory
              stories={storyHistory}
              onViewStory={handleViewStory}
              isLoading={isLoadingHistory}
            />
          </div>
        </div>

        <div className="mt-12 bg-white rounded-2xl shadow-xl p-8 border border-slate-200">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">About This System</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center mb-3">
                <span className="text-2xl">📝</span>
              </div>
              <h3 className="font-semibold text-slate-900">NLP-Powered Generation</h3>
              <p className="text-sm text-slate-600">
                Uses advanced natural language processing algorithms to create coherent, engaging narratives with proper story structure.
              </p>
            </div>
            <div className="space-y-2">
              <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center mb-3">
                <span className="text-2xl">🎨</span>
              </div>
              <h3 className="font-semibold text-slate-900">Customizable Stories</h3>
              <p className="text-sm text-slate-600">
                Choose genre, theme, characters, and keywords to personalize your story. The AI adapts to your preferences.
              </p>
            </div>
            <div className="space-y-2">
              <div className="h-12 w-12 bg-yellow-100 rounded-lg flex items-center justify-center mb-3">
                <span className="text-2xl">⚡</span>
              </div>
              <h3 className="font-semibold text-slate-900">Instant Results</h3>
              <p className="text-sm text-slate-600">
                Generate complete stories in seconds. Export, copy, or save your favorites for later reference.
              </p>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-slate-900 text-white mt-16 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-slate-400">
            AI-Based Story Generation System - Powered by Natural Language Processing
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
