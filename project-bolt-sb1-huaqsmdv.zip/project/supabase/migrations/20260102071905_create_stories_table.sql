/*
  # Create Stories Generation System Schema

  ## Overview
  This migration sets up the database schema for the AI-Based Story Generation System.
  It includes tables for storing generated stories with their metadata and parameters.

  ## Tables Created
  
  ### `stories`
  Stores all generated stories with their generation parameters and metadata
  - `id` (uuid, primary key) - Unique identifier for each story
  - `title` (text) - Title of the generated story
  - `content` (text) - The full generated story text
  - `genre` (text) - Genre selected by user (e.g., Fantasy, Sci-Fi, Romance)
  - `theme` (text) - Theme or central idea provided by user
  - `characters` (jsonb) - Array of character names/descriptions
  - `keywords` (text[]) - Array of keywords used for generation
  - `word_count` (integer) - Number of words in the generated story
  - `created_at` (timestamptz) - When the story was generated
  - `user_id` (uuid, nullable) - For future authentication integration

  ## Security
  - RLS enabled on all tables
  - Public read access for now (can be restricted later)
  - Public insert access to allow story generation without auth
  
  ## Notes
  - The system is designed to work without authentication initially
  - Can be enhanced later to support user accounts and private stories
*/

-- Create stories table
CREATE TABLE IF NOT EXISTS stories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT 'Untitled Story',
  content text NOT NULL,
  genre text NOT NULL,
  theme text,
  characters jsonb DEFAULT '[]'::jsonb,
  keywords text[] DEFAULT ARRAY[]::text[],
  word_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  user_id uuid
);

-- Enable Row Level Security
ALTER TABLE stories ENABLE ROW LEVEL SECURITY;

-- Allow public read access to all stories
CREATE POLICY "Anyone can view stories"
  ON stories FOR SELECT
  TO public
  USING (true);

-- Allow public insert access for story generation
CREATE POLICY "Anyone can create stories"
  ON stories FOR INSERT
  TO public
  WITH CHECK (true);

-- Allow users to update their own stories (based on user_id)
CREATE POLICY "Users can update their own stories"
  ON stories FOR UPDATE
  TO public
  USING (user_id IS NULL OR user_id = auth.uid())
  WITH CHECK (user_id IS NULL OR user_id = auth.uid());

-- Allow users to delete their own stories
CREATE POLICY "Users can delete their own stories"
  ON stories FOR DELETE
  TO public
  USING (user_id IS NULL OR user_id = auth.uid());

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_stories_created_at ON stories(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_stories_genre ON stories(genre);
CREATE INDEX IF NOT EXISTS idx_stories_user_id ON stories(user_id) WHERE user_id IS NOT NULL;