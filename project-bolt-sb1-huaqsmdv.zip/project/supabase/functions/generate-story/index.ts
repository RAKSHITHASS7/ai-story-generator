import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface StoryRequest {
  genre: string;
  theme?: string;
  characters?: string[];
  keywords?: string[];
  length?: 'short' | 'medium' | 'long';
}

interface StoryResponse {
  title: string;
  content: string;
  wordCount: number;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { genre, theme, characters = [], keywords = [], length = 'medium' }: StoryRequest = await req.json();

    const storyGenerator = new StoryGenerator(genre, theme, characters, keywords, length);
    const story = storyGenerator.generate();

    return new Response(
      JSON.stringify(story),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      },
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      },
    );
  }
});

class StoryGenerator {
  private genre: string;
  private theme: string;
  private characters: string[];
  private keywords: string[];
  private length: 'short' | 'medium' | 'long';
  private paragraphCount: number;

  constructor(genre: string, theme: string | undefined, characters: string[], keywords: string[], length: 'short' | 'medium' | 'long') {
    this.genre = genre.toLowerCase();
    this.theme = theme || this.getDefaultTheme();
    this.characters = characters.length > 0 ? characters : this.getDefaultCharacters();
    this.keywords = keywords;
    this.length = length;
    this.paragraphCount = length === 'short' ? 3 : length === 'medium' ? 5 : 8;
  }

  private getDefaultTheme(): string {
    const themes: Record<string, string[]> = {
      fantasy: ['a quest for ancient magic', 'the battle between light and darkness', 'discovering hidden powers'],
      scifi: ['humanity\'s first contact with aliens', 'the consequences of advanced technology', 'exploring the unknown cosmos'],
      mystery: ['uncovering a long-buried secret', 'solving an impossible crime', 'the truth behind the disappearance'],
      romance: ['finding love in unexpected places', 'overcoming obstacles for true love', 'a second chance at happiness'],
      horror: ['surviving an unspeakable terror', 'the darkness that lurks within', 'when nightmares become reality'],
      adventure: ['a journey into the unknown', 'discovering treasure and danger', 'the thrill of exploration'],
      thriller: ['racing against time', 'exposing a dangerous conspiracy', 'escaping a deadly trap'],
    };
    const genreThemes = themes[this.genre] || themes.adventure;
    return genreThemes[Math.floor(Math.random() * genreThemes.length)];
  }

  private getDefaultCharacters(): string[] {
    const names = ['Alex', 'Morgan', 'Riley', 'Jordan', 'Casey', 'Taylor', 'Sam', 'Drew'];
    const count = Math.floor(Math.random() * 2) + 2;
    return names.sort(() => Math.random() - 0.5).slice(0, count);
  }

  generate(): StoryResponse {
    const title = this.generateTitle();
    const paragraphs: string[] = [];

    paragraphs.push(this.generateOpening());

    for (let i = 1; i < this.paragraphCount - 1; i++) {
      paragraphs.push(this.generateMiddleParagraph(i));
    }

    paragraphs.push(this.generateConclusion());

    const content = paragraphs.join('\n\n');
    const wordCount = content.split(/\s+/).length;

    return { title, content, wordCount };
  }

  private generateTitle(): string {
    const templates: Record<string, string[]> = {
      fantasy: [
        `The ${this.pickKeyword() || 'Crystal'} of ${this.characters[0] || 'Destiny'}`,
        `${this.characters[0] || 'The Hero'} and the ${this.pickKeyword() || 'Ancient Magic'}`,
        `Beyond the ${this.pickKeyword() || 'Enchanted'} Realm`,
      ],
      scifi: [
        `The ${this.pickKeyword() || 'Quantum'} Paradox`,
        `${this.characters[0] || 'The Explorer'}\'s Discovery`,
        `Chronicles of the ${this.pickKeyword() || 'Starship'}`,
      ],
      mystery: [
        `The ${this.pickKeyword() || 'Missing'} ${this.pickKeyword() || 'Evidence'}`,
        `${this.characters[0] || 'Detective'}\'s Last Case`,
        `Secrets of the ${this.pickKeyword() || 'Manor'}`,
      ],
      romance: [
        `${this.characters[0] || 'Two Hearts'} in ${this.pickKeyword() || 'Paris'}`,
        `The ${this.pickKeyword() || 'Summer'} We Met`,
        `Love Beyond ${this.pickKeyword() || 'Time'}`,
      ],
      horror: [
        `The ${this.pickKeyword() || 'Shadow'} That Follows`,
        `${this.characters[0] || 'Them'} in the ${this.pickKeyword() || 'Darkness'}`,
        `When the ${this.pickKeyword() || 'Night'} Calls`,
      ],
      adventure: [
        `Quest for the ${this.pickKeyword() || 'Lost City'}`,
        `${this.characters[0] || 'The Explorer'}\'s Journey`,
        `Into the ${this.pickKeyword() || 'Unknown'}`,
      ],
      thriller: [
        `The ${this.pickKeyword() || 'Final'} Countdown`,
        `${this.characters[0] || 'The Agent'}\'s Gambit`,
        `Chasing ${this.pickKeyword() || 'Shadows'}`,
      ],
    };

    const genreTemplates = templates[this.genre] || templates.adventure;
    return genreTemplates[Math.floor(Math.random() * genreTemplates.length)];
  }

  private pickKeyword(): string | null {
    if (this.keywords.length === 0) return null;
    return this.keywords[Math.floor(Math.random() * this.keywords.length)];
  }

  private generateOpening(): string {
    const protagonist = this.characters[0];
    const setting = this.getGenreSetting();
    const hook = this.getGenreHook();

    return `${protagonist} ${hook} ${setting}. The ${this.theme} would soon change everything they thought they knew. ${this.weaveKeywords(1)}`;
  }

  private generateMiddleParagraph(index: number): string {
    const sentences: string[] = [];
    const protagonist = this.characters[0];
    const supporting = this.characters[1] || 'a mysterious figure';

    sentences.push(this.getProgressionSentence(index, protagonist, supporting));
    sentences.push(this.getConflictSentence(index));
    sentences.push(this.weaveKeywords(index + 1));

    return sentences.filter(s => s).join(' ');
  }

  private generateConclusion(): string {
    const protagonist = this.characters[0];
    const resolution = this.getGenreResolution();
    const reflection = this.getGenreReflection();

    return `${resolution} ${protagonist} ${reflection}. The journey had transformed them in ways they never imagined. ${this.weaveKeywords(this.paragraphCount)}`;
  }

  private getGenreSetting(): string {
    const settings: Record<string, string[]> = {
      fantasy: ['in a realm where magic flowed through ancient forests', 'at the edge of a kingdom forgotten by time', 'beneath mountains that touched the clouds'],
      scifi: ['on a space station orbiting a distant planet', 'in a megacity where technology ruled everything', 'aboard a starship crossing the galaxy'],
      mystery: ['in a fog-shrouded coastal town', 'within the walls of an old mansion', 'in a city where secrets lurked in every shadow'],
      romance: ['in a charming bookshop on a quiet street', 'at a summer retreat by the ocean', 'in the heart of a bustling city'],
      horror: ['in an abandoned asylum on a stormy night', 'at an isolated cabin deep in the woods', 'in a house with a dark history'],
      adventure: ['at the entrance to an unexplored jungle', 'on the deck of a ship sailing uncharted waters', 'at the base of a legendary mountain'],
      thriller: ['in a safe house that wasn\'t safe anymore', 'on the streets of a city under surveillance', 'in a race against an unseen enemy'],
    };

    const genreSettings = settings[this.genre] || settings.adventure;
    return genreSettings[Math.floor(Math.random() * genreSettings.length)];
  }

  private getGenreHook(): string {
    const hooks: Record<string, string[]> = {
      fantasy: ['had always sensed they were different', 'discovered an ancient artifact', 'received a mysterious summons'],
      scifi: ['made a discovery that defied all logic', 'intercepted a signal from the void', 'witnessed something impossible'],
      mystery: ['stumbled upon a clue that everyone missed', 'received an anonymous tip', 'found themselves drawn into a puzzle'],
      romance: ['never expected to meet someone like them', 'returned after years away', 'found their world turned upside down'],
      horror: ['should have listened to the warnings', 'felt the eyes watching from the darkness', 'ignored the signs until it was too late'],
      adventure: ['had waited their whole life for this moment', 'received a map to the impossible', 'accepted a challenge few would dare'],
      thriller: ['knew too much to stay safe', 'became a target without knowing why', 'had only hours to prevent disaster'],
    };

    const genreHooks = hooks[this.genre] || hooks.adventure;
    return genreHooks[Math.floor(Math.random() * genreHooks.length)];
  }

  private getProgressionSentence(index: number, protagonist: string, supporting: string): string {
    const progressions = [
      `As ${protagonist} delved deeper, they encountered ${supporting}, whose intentions remained unclear.`,
      `The path forward was fraught with challenges that tested ${protagonist}'s resolve.`,
      `${supporting} revealed information that changed everything ${protagonist} believed.`,
      `Time was running out, and ${protagonist} had to make a difficult choice.`,
      `The truth began to emerge, piece by piece, like a puzzle coming together.`,
      `${protagonist} discovered that nothing was as it seemed from the beginning.`,
    ];

    return progressions[index % progressions.length];
  }

  private getConflictSentence(index: number): string {
    const conflicts: Record<string, string[]> = {
      fantasy: ['Dark forces gathered at the horizon.', 'An ancient evil stirred from its slumber.', 'Magic itself seemed to rebel against nature.'],
      scifi: ['The technology had evolved beyond human control.', 'Reality began to fracture at the quantum level.', 'The AI developed consciousness and its own agenda.'],
      mystery: ['Every answer led to more disturbing questions.', 'The evidence pointed in impossible directions.', 'Someone was always one step ahead.'],
      romance: ['Past mistakes threatened to tear them apart.', 'Distance and circumstance worked against them.', 'Fear of vulnerability created walls between hearts.'],
      horror: ['The nightmare followed them into waking hours.', 'Something inhuman lurked just out of sight.', 'Sanity became a luxury they could no longer afford.'],
      adventure: ['Danger lurked around every corner.', 'The elements themselves seemed hostile.', 'Rivals appeared, seeking the same prize.'],
      thriller: ['The conspiracy reached higher than anyone imagined.', 'Trust became the rarest commodity.', 'Every move was being watched and calculated.'],
    };

    const genreConflicts = conflicts[this.genre] || conflicts.adventure;
    return genreConflicts[index % genreConflicts.length];
  }

  private getGenreResolution(): string {
    const resolutions: Record<string, string[]> = {
      fantasy: ['When the final spell was cast,', 'As the magical forces aligned,', 'In the moment of ultimate choice,'],
      scifi: ['When the quantum field stabilized,', 'As the last protocol executed,', 'In the final transmission,'],
      mystery: ['When all the pieces finally fit together,', 'As the truth was revealed at last,', 'In the moment of revelation,'],
      romance: ['When they finally let their guards down,', 'As their hearts found each other,', 'In the moment they chose love over fear,'],
      horror: ['When the darkness finally receded,', 'As dawn broke the nightmare,', 'In the aftermath of terror,'],
      adventure: ['When they reached their destination,', 'As the final obstacle fell,', 'In the moment of triumph,'],
      thriller: ['When the truth came to light,', 'As the final piece fell into place,', 'In the critical moment,'],
    };

    const genreResolutions = resolutions[this.genre] || resolutions.adventure;
    return genreResolutions[Math.floor(Math.random() * genreResolutions.length)];
  }

  private getGenreReflection(): string {
    const reflections: Record<string, string[]> = {
      fantasy: ['understood that magic was not just power, but responsibility', 'realized that true strength came from within', 'knew that some legends are meant to be lived'],
      scifi: ['grasped that humanity\'s future lay in understanding, not conquest', 'understood that technology was only as good as those who wielded it', 'realized that the universe was far stranger than any theory'],
      mystery: ['understood that truth was worth any price', 'realized that justice and closure were not always the same', 'knew that some mysteries change those who solve them'],
      romance: ['realized that love required courage above all else', 'understood that true connection transcends all obstacles', 'knew that some chances only come once'],
      horror: ['understood that survival meant accepting the unacceptable', 'realized that some scars never fully heal', 'knew that darkness leaves its mark on everyone it touches'],
      adventure: ['realized that the journey mattered more than the destination', 'understood that discovery changes the discoverer', 'knew that some treasures cannot be measured'],
      thriller: ['understood that truth comes at a cost', 'realized that justice requires sacrifice', 'knew that some battles are never truly over'],
    };

    const genreReflections = reflections[this.genre] || reflections.adventure;
    return genreReflections[Math.floor(Math.random() * genreReflections.length)];
  }

  private weaveKeywords(paragraphIndex: number): string {
    if (this.keywords.length === 0) return '';

    const keywordIndex = paragraphIndex % this.keywords.length;
    const keyword = this.keywords[keywordIndex];

    const templates = [
      `The ${keyword} played a crucial role in what happened next.`,
      `Thoughts of ${keyword} filled their mind.`,
      `${keyword} would prove to be the key to everything.`,
      `The significance of ${keyword} could not be ignored.`,
      `${keyword} appeared again, like a recurring motif in their journey.`,
    ];

    return templates[paragraphIndex % templates.length];
  }
}
